﻿namespace TomagochiApi.Interfaces;

public interface IInventoryService
{
    
}