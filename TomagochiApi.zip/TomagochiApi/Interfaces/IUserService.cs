﻿namespace TomagochiApi.Interfaces;

public interface IUserService
{
    
}